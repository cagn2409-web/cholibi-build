package com.cholibi.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.util.Log;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.concurrent.Executor;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * CholibiSecurityAndProxyManager — Quản lý bảo mật thông tin nhạy cảm bằng Android Keystore (AES-GCM 256-bit),
 * lưu trữ trạng thái phản hồi A11Y_STATUS đồng bộ với DroidScript/WebView, và áp dụng Proxy thực tế ở tầng Native Android.
 */
public final class CholibiSecurityAndProxyManager {
    private static final String TAG = "CholibiSecProxy";
    private static final String ANDROID_KEYSTORE = "AndroidKeyStore";
    private static final String KEY_ALIAS = "CholibiMasterKey_v2";
    private static final String PREF_NAME = "cholibi_encrypted_vault";
    private static final String DROIDSCRIPT_STORAGE_PREF = "CHOLIBI_APP_STORAGE_V6";
    private static final int GCM_TAG_LENGTH = 128;

    private final Context context;
    private final SharedPreferences prefs;

    public CholibiSecurityAndProxyManager(Context context) {
        this.context = context.getApplicationContext();
        this.prefs = this.context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        ensureMasterKey();
    }

    private void ensureMasterKey() {
        try {
            KeyStore ks = KeyStore.getInstance(ANDROID_KEYSTORE);
            ks.load(null);
            if (!ks.containsAlias(KEY_ALIAS)) {
                KeyGenerator keyGen = KeyGenerator.getInstance(
                        KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE);
                KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(
                        KEY_ALIAS,
                        KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                        .setKeySize(256)
                        .build();
                keyGen.init(spec);
                keyGen.generateKey();
            }
        } catch (Exception e) {
            Log.e(TAG, "Không thể khởi tạo khóa Android Keystore: " + e.getMessage());
        }
    }

    /** Mã hóa chuỗi nhạy cảm bằng khóa phần cứng AndroidKeyStore (AES/GCM/NoPadding). */
    public boolean saveEncryptedSecret(String key, String plainSecret) {
        if (plainSecret == null || plainSecret.isEmpty()) {
            prefs.edit().remove(key).apply();
            return true;
        }
        try {
            KeyStore ks = KeyStore.getInstance(ANDROID_KEYSTORE);
            ks.load(null);
            SecretKey secretKey = ((KeyStore.SecretKeyEntry) ks.getEntry(KEY_ALIAS, null)).getSecretKey();

            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            byte[] iv = cipher.getIV();
            byte[] cipherText = cipher.doFinal(plainSecret.getBytes(StandardCharsets.UTF_8));

            String payload = Base64.encodeToString(iv, Base64.NO_WRAP)
                    + ":" + Base64.encodeToString(cipherText, Base64.NO_WRAP);
            prefs.edit().putString(key, payload).apply();
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Lỗi mã hóa Keystore cho khóa [" + key + "]: " + e.getMessage());
            return false;
        }
    }

    /** Giải mã chuỗi nhạy cảm từ AndroidKeyStore trực tiếp vào bộ nhớ RAM khi cần điền. */
    public String readEncryptedSecret(String key) {
        String stored = prefs.getString(key, null);
        if (stored == null || !stored.contains(":")) return "";
        try {
            String[] parts = stored.split(":", 2);
            byte[] iv = Base64.decode(parts[0], Base64.NO_WRAP);
            byte[] cipherText = Base64.decode(parts[1], Base64.NO_WRAP);

            KeyStore ks = KeyStore.getInstance(ANDROID_KEYSTORE);
            ks.load(null);
            SecretKey secretKey = ((KeyStore.SecretKeyEntry) ks.getEntry(KEY_ALIAS, null)).getSecretKey();

            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            GCMParameterSpec spec = new GCMParameterSpec(GCM_TAG_LENGTH, iv);
            cipher.init(Cipher.DECRYPT_MODE, secretKey, spec);
            byte[] decoded = cipher.doFinal(cipherText);
            return new String(decoded, StandardCharsets.UTF_8);
        } catch (Exception e) {
            Log.e(TAG, "Lỗi giải mã Keystore cho khóa [" + key + "]: " + e.getMessage());
            return "";
        }
    }

    /** Lưu trạng thái A11Y_STATUS mới nhất vào cả SharedPreferences nội bộ và kho DroidScript (A11Y_LAST_STATUS_JSON). */
    public void saveLastA11yStatusJson(String statusJson) {
        if (statusJson == null) return;
        try {
            prefs.edit().putString("last_a11y_status_json", statusJson).apply();
            SharedPreferences dsPrefs = context.getSharedPreferences(DROIDSCRIPT_STORAGE_PREF, Context.MODE_PRIVATE);
            dsPrefs.edit().putString("A11Y_LAST_STATUS_JSON", statusJson).apply();
        } catch (Exception ignored) {}
    }

    public String readLastA11yStatusJson() {
        return prefs.getString("last_a11y_status_json", "");
    }

    public void clearAllSecrets() {
        prefs.edit().clear().apply();
    }

    /**
     * Áp dụng Proxy cho WebView thông qua reflection tới androidx.webkit.ProxyController
     * (nếu thư viện androidx.webkit có mặt trong APK) hoặc cấu hình System http.proxyHost.
     */
    public boolean applyNativeWebViewProxy(String host, int port, String user, String pass) {
        saveEncryptedSecret("proxy_user", user);
        saveEncryptedSecret("proxy_pass", pass);

        if (host == null || host.trim().isEmpty() || port <= 0) {
            clearNativeWebViewProxy();
            return true;
        }

        try {
            Class<?> featureCls = Class.forName("androidx.webkit.WebViewFeature");
            java.lang.reflect.Method isSupported = featureCls.getMethod("isFeatureSupported", String.class);
            Boolean supported = (Boolean) isSupported.invoke(null, "PROXY_OVERRIDE");
            if (Boolean.TRUE.equals(supported)) {
                Class<?> configBuilderCls = Class.forName("androidx.webkit.ProxyConfig$Builder");
                Object builder = configBuilderCls.getConstructor().newInstance();
                configBuilderCls.getMethod("addProxyRule", String.class)
                        .invoke(builder, host.trim() + ":" + port);
                Object proxyConfig = configBuilderCls.getMethod("build").invoke(builder);

                Class<?> controllerCls = Class.forName("androidx.webkit.ProxyController");
                Object controller = controllerCls.getMethod("getInstance").invoke(null);
                Executor directExec = new Executor() {
                    @Override public void execute(Runnable r) { r.run(); }
                };
                Runnable listener = new Runnable() {
                    @Override public void run() {
                        Log.i(TAG, "Đã áp dụng ProxyOverride thực tế cho WebView: " + host + ":" + port);
                    }
                };
                controllerCls.getMethod("setProxyOverride",
                        Class.forName("androidx.webkit.ProxyConfig"), Executor.class, Runnable.class)
                        .invoke(controller, proxyConfig, directExec, listener);
                return true;
            }
        } catch (Throwable ignored) {}

        System.setProperty("http.proxyHost", host.trim());
        System.setProperty("http.proxyPort", String.valueOf(port));
        System.setProperty("https.proxyHost", host.trim());
        System.setProperty("https.proxyPort", String.valueOf(port));
        return false;
    }

    public void clearNativeWebViewProxy() {
        saveEncryptedSecret("proxy_user", "");
        saveEncryptedSecret("proxy_pass", "");
        System.clearProperty("http.proxyHost");
        System.clearProperty("http.proxyPort");
        System.clearProperty("https.proxyHost");
        System.clearProperty("https.proxyPort");
    }
}
