package com.cholibi.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import org.json.JSONObject;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/**
 * CholibiAccessibilityService — Dịch vụ Android Accessibility điều khiển xuyên ứng dụng
 * cho Orbita / GoLogin / Chrome / WebView (Phiên bản v31.2 Master Fixed - Đồng bộ hoàn chỉnh JS <-> Java).
 *
 * Đã khắc phục triệt để 4 điểm kết nối JS <-> Java:
 * 1. Nhận và mã hóa đầy đủ cả `pw` (Mật khẩu) và `wd` (PIN rút tiền) qua CholibiSecurityAndProxyManager
 *    (AndroidKeyStore AES-GCM 256-bit) để luôn điền được cả ô mật khẩu, xác nhận mật khẩu và PIN rút tiền.
 * 2. Chỉ lắng nghe kênh `ACTION_STEP_EXEC` (loại bỏ lắng nghe trùng `ACTION_AUTOX_EXEC`) kèm bộ lọc chống trùng
 *    `lastProcessedCmdId` để mỗi thao tác chỉ thực thi đúng 1 lần duy nhất.
 * 3. Phát phản hồi 2 chiều `com.cholibi.app.A11Y_STATUS` (kèm `payload_json`, ghi vào `A11Y_LAST_STATUS_JSON`
 *    và gọi trực tiếp `MainActivity.deliverA11yStatusToWebView`) để JS hiển thị chính xác SUCCESS / FAILED / PENDING.
 * 4. Triển khai đầy đủ logic riêng biệt cho từng lệnh:
 *    - `RUN_AUTO` (Luồng tự động liên hoàn 4 bước: Mở form ĐK -> Điền form -> Tự bắt sự kiện gõ xong 4–6 ký tự
 *      Mã xác minh để bấm Đăng ký -> Đặt PIN rút tiền -> Liên kết Ngân hàng & chờ máy chủ xác nhận).
 *    - `FILL_CURRENT_FORM` (Tự nhận diện trang Đăng ký hoặc Ngân hàng để điền nhanh, không tự bấm gửi sớm).
 *    - `NEW_USER_AND_FILL` (Đổi sang TK mới giữ nguyên phôi khóa, xóa ô Mã xác minh cũ, điền lại và focus ô mã).
 *    - `GO_BANK_PAGE` (Tự chuyển vào mục Rút tiền / Tài khoản nhận / Thêm ngân hàng, chọn đúng Bank, điền Chi nhánh
 *      & STK, bấm Gửi và xác minh kết quả thực từ máy chủ).
 *    - `SUBMIT_NOW`, `CLEAN_POPUPS`, `FILL_SINGLE_FIELD`.
 */
public final class CholibiAccessibilityService extends AccessibilityService {
    private static final String TAG = "CholibiA11y";
    public static final String ACTION_SYNC_PROFILE = "com.cholibi.action.SYNC_PROFILE";
    public static final String ACTION_SET_PROXY    = "com.cholibi.action.SET_PROXY";
    public static final String ACTION_CLEAR_PROXY  = "com.cholibi.action.CLEAR_PROXY";
    public static final String ACTION_STEP_EXEC    = "com.cholibi.action.STEP_EXEC";
    public static final String ACTION_SLIDER_DRAG  = "com.cholibi.action.SLIDER_DRAG";
    public static final String ACTION_A11Y_STATUS  = "com.cholibi.app.A11Y_STATUS";

    private JSONObject activeProfile = new JSONObject();
    private boolean pausedForUserVerification = false;
    private boolean autoRunMode = false;
    private int currentAutoStage = 0; // 0: Idle, 1: Register, 2: Withdraw PIN, 3: Add Bank
    private boolean waitingVerificationCodeAutoSubmit = false;
    private String lastProcessedCmdId = "";
    private String lastAutoSubmittedCode = "";
    private long rateLimitCooldownUntilMs = 0L;
    private Runnable pendingCodeAutoSubmitRunnable = null;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private CholibiSecurityAndProxyManager securityAndProxyManager;

    private final BroadcastReceiver commandReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent == null || intent.getAction() == null) return;
            String action = intent.getAction();
            try {
                String payloadJsonStr = extractPayloadJson(intent);
                JSONObject data = (payloadJsonStr != null && !payloadJsonStr.isEmpty())
                        ? new JSONObject(payloadJsonStr) : new JSONObject();

                // Chống xử lý trùng cùng 1 cmdId (Fix #2)
                String cmdId = data.optString("cmdId", "");
                if (!cmdId.isEmpty()) {
                    if (cmdId.equals(lastProcessedCmdId)) {
                        return;
                    }
                    lastProcessedCmdId = cmdId;
                }

                if (ACTION_SYNC_PROFILE.equals(action)) {
                    mergeProfileData(data);
                    pausedForUserVerification = false;
                    Log.i(TAG, "Đã đồng bộ phôi cho site: " + activeProfile.optString("site", "NOHU88")
                            + " (TK: " + activeProfile.optString("username", "***") + ")");
                } else if (ACTION_SET_PROXY.equals(action)) {
                    String host = data.optString("host", "");
                    int port = data.optInt("port", 0);
                    String user = data.optString("user", "");
                    String pass = data.optString("pass", "");
                    if (securityAndProxyManager != null) {
                        boolean nativeApplied = securityAndProxyManager.applyNativeWebViewProxy(host, port, user, pass);
                        Log.i(TAG, "Cấu hình Proxy [" + host + ":" + port + "] -> NativeOverride=" + nativeApplied);
                        broadcastStatusToApp("SET_PROXY", "SUCCESS", "Đã áp dụng cấu hình Proxy " + host + ":" + port);
                    }
                } else if (ACTION_CLEAR_PROXY.equals(action)) {
                    if (securityAndProxyManager != null) {
                        securityAndProxyManager.clearNativeWebViewProxy();
                    }
                } else if (ACTION_STEP_EXEC.equals(action)) {
                    if (data.length() > 0) {
                        mergeProfileData(data);
                    }
                    String cmd = data.optString("cmd", "FILL_CURRENT_FORM");
                    pausedForUserVerification = false;
                    dispatchSpecificCommand(cmd, data.optJSONObject("extra"));
                } else if (ACTION_SLIDER_DRAG.equals(action)) {
                    float startX = (float) data.optDouble("startX", 0);
                    float startY = (float) data.optDouble("startY", 0);
                    float distX  = (float) data.optDouble("distanceX", 0);
                    float distY  = (float) data.optDouble("distanceY", 0);
                    int durMs    = data.optInt("durationMs", 900);
                    performTrustedDrag(startX, startY, distX, distY, durMs);
                }
            } catch (Exception e) {
                Log.w(TAG, "Lỗi xử lý lệnh Broadcast: " + e.getMessage());
                broadcastStatusToApp("STEP_EXEC", "FAILED", "Lỗi xử lý lệnh Accessibility: " + e.getMessage());
            }
        }
    };

    /**
     * Hợp nhất thông tin phôi vào activeProfile và lưu bảo mật pw/wd vào AndroidKeyStore (Fix #1).
     */
    private void mergeProfileData(JSONObject incoming) {
        if (incoming == null) return;
        try {
            if (activeProfile == null) activeProfile = new JSONObject();
            String[] keys = new String[]{
                    "site", "username", "pw", "wd", "name", "phone",
                    "bank", "branch", "stk", "stkBackup", "cmd"
            };
            for (String k : keys) {
                if (incoming.has(k) && !incoming.isNull(k)) {
                    String v = incoming.optString(k, "").trim();
                    if (!v.isEmpty() || "username".equals(k)) {
                        activeProfile.put(k, v);
                        if ("pw".equals(k) && securityAndProxyManager != null) {
                            securityAndProxyManager.saveEncryptedSecret("profile_pw", v);
                        } else if ("wd".equals(k) && securityAndProxyManager != null) {
                            securityAndProxyManager.saveEncryptedSecret("profile_wd", v);
                        }
                    }
                }
            }
            // Khôi phục pw và wd từ AndroidKeyStore nếu gói tin đồng bộ không gửi kèm
            if (securityAndProxyManager != null) {
                if (activeProfile.optString("pw", "").isEmpty()) {
                    String savedPw = securityAndProxyManager.readEncryptedSecret("profile_pw");
                    if (!savedPw.isEmpty()) activeProfile.put("pw", savedPw);
                }
                if (activeProfile.optString("wd", "").isEmpty()) {
                    String savedWd = securityAndProxyManager.readEncryptedSecret("profile_wd");
                    if (!savedWd.isEmpty()) activeProfile.put("wd", savedWd);
                }
            }
            if (activeProfile.optString("wd", "").isEmpty()) {
                activeProfile.put("wd", "123123");
            }
        } catch (Exception ignored) {}
    }

    private String extractPayloadJson(Intent intent) {
        String direct = intent.getStringExtra("payload_json");
        if (direct != null && !direct.isEmpty()) return direct;
        return null;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        securityAndProxyManager = new CholibiSecurityAndProxyManager(this);

        // Chỉ đăng ký 1 kênh lệnh điều khiển ACTION_STEP_EXEC để không bao giờ bị chạy trùng 2 lần (Fix #2)
        IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_SYNC_PROFILE);
        filter.addAction(ACTION_SET_PROXY);
        filter.addAction(ACTION_CLEAR_PROXY);
        filter.addAction(ACTION_STEP_EXEC);
        filter.addAction(ACTION_SLIDER_DRAG);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(commandReceiver, filter, Context.RECEIVER_EXPORTED);
        } else {
            registerReceiver(commandReceiver, filter);
        }
        Log.i(TAG, "CholibiAccessibilityService v31.2 đã kết nối sẵn sàng.");
        broadcastStatusToApp("INIT", "SUCCESS", "Dịch vụ Trợ năng CHOLIBI v31.2 đã sẵn sàng.");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || pausedForUserVerification) return;
        if (System.currentTimeMillis() < rateLimitCooldownUntilMs) return;

        CharSequence pkg = event.getPackageName();
        if (pkg == null) return;
        String pkgName = pkg.toString().toLowerCase();

        if (!pkgName.contains("orbita") && !pkgName.contains("gologin")
                && !pkgName.contains("chrome") && !pkgName.contains("cholibi")) {
            return;
        }

        int type = event.getEventType();

        // Tự động theo dõi ô Mã xác minh (4–6 ký tự cuối form): khi người dùng gõ đủ 4–6 ký tự thì tự bấm Đăng ký!
        if (waitingVerificationCodeAutoSubmit && (type == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED
                || type == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED)) {
            checkVerificationCodeAndScheduleAutoSubmit();
            return;
        }

        if (autoRunMode && (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                || type == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED)) {
            continueAutoRunStageOnWindowChange();
        }
    }

    @Override
    public void onInterrupt() {
        Log.i(TAG, "CholibiAccessibilityService tạm ngắt.");
    }

    @Override
    public void onDestroy() {
        try {
            unregisterReceiver(commandReceiver);
        } catch (Exception ignored) {}
        super.onDestroy();
    }

    /**
     * Phân luồng thực thi riêng biệt cho từng lệnh (Fix #4):
     * RUN_AUTO, FILL_CURRENT_FORM, NEW_USER_AND_FILL, SUBMIT_NOW, GO_BANK_PAGE, CLEAN_POPUPS, FILL_SINGLE_FIELD.
     */
    private void dispatchSpecificCommand(String cmd, JSONObject extra) {
        if (System.currentTimeMillis() < rateLimitCooldownUntilMs) {
            long remSec = Math.max(1L, (rateLimitCooldownUntilMs - System.currentTimeMillis()) / 1000L);
            broadcastStatusToApp(cmd, "PENDING", "Đang nghỉ chống lỗi 429 (còn " + remSec + "s)...");
            return;
        }

        String normalizedCmd = (cmd != null && !cmd.isEmpty()) ? cmd.trim().toUpperCase() : "FILL_CURRENT_FORM";

        switch (normalizedCmd) {
            case "CLEAN_POPUPS":
                handleCleanPopupsCommand();
                break;
            case "FILL_SINGLE_FIELD":
                handleFillSingleFieldCommand(extra);
                break;
            case "NEW_USER_AND_FILL":
                handleNewUserAndFillCommand(extra);
                break;
            case "SUBMIT_NOW":
                handleSubmitNowCommand();
                break;
            case "GO_BANK_PAGE":
                handleGoBankPageCommand();
                break;
            case "RUN_AUTO":
                handleRunAutoCommand();
                break;
            case "FILL_CURRENT_FORM":
            case "STEP_EXEC":
            default:
                handleFillCurrentFormCommand();
                break;
        }
    }

    // =========================================================================
    // 1. LỆNH CLEAN_POPUPS: Đóng toàn bộ hộp thoại / quảng cáo che màn hình
    // =========================================================================
    private void handleCleanPopupsCommand() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            broadcastStatusToApp("CLEAN_POPUPS", "PENDING", "Đang đợi cửa sổ trình duyệt...");
            return;
        }
        try {
            int closed = dismissPopupsInTree(root);
            broadcastStatusToApp("CLEAN_POPUPS", "SUCCESS",
                    closed > 0 ? ("Đã đóng " + closed + " hộp thoại / quảng cáo.") : "Màn hình đã sạch popup.");
        } finally {
            root.recycle();
        }
    }

    // =========================================================================
    // 2. LỆNH FILL_SINGLE_FIELD: Điền lẻ đúng 1 trường được yêu cầu
    // =========================================================================
    private void handleFillSingleFieldCommand(JSONObject extra) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            broadcastStatusToApp("FILL_SINGLE_FIELD", "PENDING", "Đang đợi cửa sổ trình duyệt...");
            return;
        }
        try {
            String field = extra != null ? extra.optString("field", "") : "";
            String val = extra != null ? extra.optString("value", "") : "";
            if (val.isEmpty() && activeProfile != null) {
                val = activeProfile.optString(field, "");
            }
            boolean ok = fillSingleFieldByType(root, field, val);
            broadcastStatusToApp(
                    "FILL_SINGLE_FIELD",
                    ok ? "SUCCESS" : "FAILED",
                    ok ? ("Đã điền trường " + field.toUpperCase() + " thành công.")
                       : ("Không tìm thấy ô " + field.toUpperCase() + " trên màn hình hiện tại.")
            );
        } finally {
            root.recycle();
        }
    }

    // =========================================================================
    // 3. LỆNH NEW_USER_AND_FILL: Đổi TK mới (giữ nguyên phôi khóa), xóa mã cũ & điền lại
    // =========================================================================
    private void handleNewUserAndFillCommand(JSONObject extra) {
        try {
            if (extra != null && extra.has("username")) {
                String newU = extra.optString("username", "").trim();
                if (!newU.isEmpty()) {
                    activeProfile.put("username", newU);
                }
            }
        } catch (Exception ignored) {}

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            broadcastStatusToApp("NEW_USER_AND_FILL", "PENDING",
                    "Đã đổi TK sang " + activeProfile.optString("username", "") + " (Chờ mở form để điền).");
            return;
        }
        try {
            AccessibilityNodeInfo verNode = findVerificationCodeNode(root);
            if (verNode != null) {
                setNodeTextValue(verNode, "");
            }
            int count = fillRegistrationFieldsOnScreen(root);
            String curUser = activeProfile.optString("username", "");
            if (verNode != null) {
                verNode.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
                waitingVerificationCodeAutoSubmit = true;
                lastAutoSubmittedCode = "";
            }
            broadcastStatusToApp(
                    "NEW_USER_AND_FILL",
                    count > 0 ? "SUCCESS" : "PENDING",
                    count > 0
                            ? ("Đã đổi TK mới (" + curUser + ") & điền lại " + count + " ô trên biểu mẫu!")
                            : ("Đã tạo TK mới (" + curUser + ") — Hãy mở trang Đăng ký để điền.")
            );
        } finally {
            root.recycle();
        }
    }

    // =========================================================================
    // 4. LỆNH FILL_CURRENT_FORM: Nhận diện trang hiện tại (ĐK hoặc Bank) & điền
    // =========================================================================
    private void handleFillCurrentFormCommand() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            broadcastStatusToApp("FILL_CURRENT_FORM", "PENDING", "Đang đợi cửa sổ trình duyệt...");
            return;
        }
        try {
            if (checkAndHandleServerAlert(root, "FILL_CURRENT_FORM")) return;
            dismissPopupsInTree(root);

            if (isBankFormScreen(root)) {
                int bankFilled = fillBankFieldsOnScreen(root, false);
                broadcastStatusToApp(
                        "FILL_CURRENT_FORM",
                        bankFilled > 0 ? "SUCCESS" : "PENDING",
                        bankFilled > 0 ? ("Đã điền " + bankFilled + " trường Ngân hàng / STK.") : "Chưa thấy ô nhập STK trên trang."
                );
                return;
            }

            int regFilled = fillRegistrationFieldsOnScreen(root);
            AccessibilityNodeInfo verNode = findVerificationCodeNode(root);
            if (verNode != null) {
                verNode.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
                waitingVerificationCodeAutoSubmit = true;
                lastAutoSubmittedCode = "";
                broadcastStatusToApp("FILL_CURRENT_FORM", "PENDING",
                        "Đã điền " + regFilled + " ô & trỏ vào ô Mã xác minh (4–6 ký tự cuối form).");
            } else if (regFilled > 0) {
                broadcastStatusToApp("FILL_CURRENT_FORM", "SUCCESS",
                        "Đã điền xong " + regFilled + " ô biểu mẫu (" + activeProfile.optString("username", "") + ").");
            } else {
                broadcastStatusToApp("FILL_CURRENT_FORM", "PENDING",
                        "Chưa thấy biểu mẫu Đăng ký trên màn hình hiện tại.");
            }
        } finally {
            root.recycle();
        }
    }

    // =========================================================================
    // 5. LỆNH SUBMIT_NOW: Tích điều khoản, bấm nút Đăng ký, dọn popup & chờ máy chủ
    // =========================================================================
    private void handleSubmitNowCommand() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            broadcastStatusToApp("SUBMIT_NOW", "FAILED", "Không đọc được cửa sổ trình duyệt hiện tại.");
            return;
        }
        try {
            if (checkAndHandleServerAlert(root, "SUBMIT_NOW")) return;
            tickAgreementCheckboxes(root);
            AccessibilityNodeInfo submitBtn = findRegisterSubmitButton(root);
            if (submitBtn != null && clickNodeOrTapBounds(submitBtn)) {
                waitingVerificationCodeAutoSubmit = false;
                broadcastStatusToApp("SUBMIT_NOW", "PENDING",
                        "Đã bấm nút Đăng ký (" + activeProfile.optString("username", "") + ") — Đang chờ máy chủ xác nhận...");
                schedulePostRegisterVerification();
            } else {
                broadcastStatusToApp("SUBMIT_NOW", "FAILED", "Không tìm thấy nút Đăng Ký trên màn hình hiện tại!");
            }
        } finally {
            root.recycle();
        }
    }

    // =========================================================================
    // 6. LỆNH GO_BANK_PAGE: Vào trang Ngân hàng, chọn Bank + Chi nhánh + STK & Gửi
    // =========================================================================
    private void handleGoBankPageCommand() {
        String stk = activeProfile != null ? activeProfile.optString("stk", "").trim() : "";
        if (stk.isEmpty()) {
            broadcastStatusToApp("GO_BANK_PAGE", "FAILED", "Ô Số tài khoản (STK) đang trống — Không tự sinh STK giả!");
            return;
        }

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            broadcastStatusToApp("GO_BANK_PAGE", "PENDING", "Đang đợi cửa sổ trình duyệt...");
            return;
        }
        try {
            if (checkAndHandleServerAlert(root, "GO_BANK_PAGE")) return;
            dismissPopupsInTree(root);

            if (!isBankFormScreen(root)) {
                AccessibilityNodeInfo navNode = findClickableNodeByKeywords(root,
                        new String[]{"rút tiền", "tài khoản nhận", "tài khoản ngân hàng", "thêm tài khoản", "thêm ngân hàng"});
                if (navNode != null && clickNodeOrTapBounds(navNode)) {
                    broadcastStatusToApp("GO_BANK_PAGE", "PENDING", "Đang mở mục Rút tiền / Liên kết Ngân hàng...");
                    mainHandler.postDelayed(this::handleGoBankPageCommand, 1000L);
                    return;
                }
            }

            int filled = fillBankFieldsOnScreen(root, true);
            if (filled > 0) {
                broadcastStatusToApp("GO_BANK_PAGE", "PENDING",
                        "Đã điền & gửi biểu mẫu Ngân hàng — Đang chờ máy chủ xác nhận liên kết...");
                scheduleBankOutcomeVerification(stk);
            } else {
                broadcastStatusToApp("GO_BANK_PAGE", "PENDING",
                        "Trang Ngân hàng đang tải, hãy bấm lại khi ô nhập STK hiển thị.");
            }
        } finally {
            root.recycle();
        }
    }

    // =========================================================================
    // 7. LỆNH RUN_AUTO: Luồng Tự Động Liên Hoàn (Đóng Popup -> Mở ĐK -> Điền -> Chờ Mã -> PIN -> Bank)
    // =========================================================================
    private void handleRunAutoCommand() {
        autoRunMode = true;
        currentAutoStage = 1;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            broadcastStatusToApp("RUN_AUTO", "PENDING", "Đang đợi cửa sổ trình duyệt sẵn sàng...");
            return;
        }
        try {
            if (checkAndHandleServerAlert(root, "RUN_AUTO")) return;
            dismissPopupsInTree(root);

            // Nếu đang ở trang Ngân hàng thì chạy thẳng Bước 3
            if (isBankFormScreen(root)) {
                currentAutoStage = 3;
                handleGoBankPageCommand();
                return;
            }

            List<AccessibilityNodeInfo> editables = new ArrayList<>();
            collectEditableNodes(root, editables);
            if (editables.size() < 3) {
                AccessibilityNodeInfo regHeaderBtn = findClickableNodeByKeywords(root,
                        new String[]{"đăng ký", "đăng kí", "register"});
                if (regHeaderBtn != null && clickNodeOrTapBounds(regHeaderBtn)) {
                    broadcastStatusToApp("RUN_AUTO", "PENDING", "Đã bấm mở trang Đăng ký — Đang đợi biểu mẫu tải xong...");
                    mainHandler.postDelayed(this::handleRunAutoCommand, 1050L);
                    return;
                }
            }

            int filled = fillRegistrationFieldsOnScreen(root);
            AccessibilityNodeInfo verNode = findVerificationCodeNode(root);
            if (verNode != null) {
                CharSequence curCode = verNode.getText();
                String codeStr = curCode != null ? curCode.toString().trim() : "";
                if (codeStr.length() < 4) {
                    verNode.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
                    waitingVerificationCodeAutoSubmit = true;
                    lastAutoSubmittedCode = "";
                    broadcastStatusToApp("RUN_AUTO", "PENDING",
                            "Đã điền " + filled + " ô — Hãy gõ 4–6 ký tự Mã xác minh để tự bấm Đăng ký!");
                    return;
                }
            }

            AccessibilityNodeInfo submitBtn = findRegisterSubmitButton(root);
            if (submitBtn != null && clickNodeOrTapBounds(submitBtn)) {
                waitingVerificationCodeAutoSubmit = false;
                broadcastStatusToApp("RUN_AUTO", "PENDING",
                        "Đã tự bấm Đăng ký (" + activeProfile.optString("username", "") + ") — Đang chờ máy chủ xác nhận...");
                schedulePostRegisterVerification();
            } else {
                broadcastStatusToApp("RUN_AUTO", "PENDING",
                        "Đã điền " + filled + " ô trên trang hiện tại.");
            }
        } finally {
            root.recycle();
        }
    }

    /**
     * Theo dõi ô Mã xác minh (4–6 ký tự cuối form):
     * - Đạt đúng 6 ký tự: tự động bấm nút Đăng ký sau 100ms.
     * - Đạt 4 hoặc 5 ký tự (VD: 1232 hoặc 34525): chờ 420ms sau phím gõ cuối để không cắt ngang khi đang gõ chữ số thứ 5–6,
     *   rồi tự động bấm nút Đăng ký!
     */
    private void checkVerificationCodeAndScheduleAutoSubmit() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        try {
            AccessibilityNodeInfo verNode = findVerificationCodeNode(root);
            if (verNode == null) return;
            CharSequence txt = verNode.getText();
            final String codeVal = txt != null ? txt.toString().trim() : "";
            if (codeVal.length() < 4 || codeVal.length() > 6) {
                if (pendingCodeAutoSubmitRunnable != null) {
                    mainHandler.removeCallbacks(pendingCodeAutoSubmitRunnable);
                    pendingCodeAutoSubmitRunnable = null;
                }
                return;
            }
            if (codeVal.equals(lastAutoSubmittedCode)) return;

            if (pendingCodeAutoSubmitRunnable != null) {
                mainHandler.removeCallbacks(pendingCodeAutoSubmitRunnable);
            }
            long delayMs = (codeVal.length() >= 6) ? 100L : 420L;
            pendingCodeAutoSubmitRunnable = () -> {
                AccessibilityNodeInfo latestRoot = getRootInActiveWindow();
                if (latestRoot == null) return;
                try {
                    AccessibilityNodeInfo latestVer = findVerificationCodeNode(latestRoot);
                    String finalCode = (latestVer != null && latestVer.getText() != null)
                            ? latestVer.getText().toString().trim() : codeVal;
                    if (finalCode.length() >= 4 && finalCode.length() <= 6 && !finalCode.equals(lastAutoSubmittedCode)) {
                        lastAutoSubmittedCode = finalCode;
                        waitingVerificationCodeAutoSubmit = false;
                        tickAgreementCheckboxes(latestRoot);
                        AccessibilityNodeInfo regBtn = findRegisterSubmitButton(latestRoot);
                        if (regBtn != null && clickNodeOrTapBounds(regBtn)) {
                            broadcastStatusToApp("SUBMIT_NOW", "PENDING",
                                    "Đã nhận Mã xác minh [" + finalCode + "] & tự bấm Đăng ký — Chờ máy chủ xác nhận!");
                            schedulePostRegisterVerification();
                        }
                    }
                } finally {
                    latestRoot.recycle();
                }
            };
            mainHandler.postDelayed(pendingCodeAutoSubmitRunnable, delayMs);
        } finally {
            root.recycle();
        }
    }

    private void schedulePostRegisterVerification() {
        mainHandler.postDelayed(() -> {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root == null) return;
            try {
                if (checkAndHandleServerAlert(root, "SUBMIT_NOW")) return;
                String allText = collectVisibleScreenText(root);
                boolean hasCongrats = allText.contains("chúc mừng bạn đã đăng ký thành công")
                        || allText.contains("xin chúc mừng! đăng ký thành công")
                        || allText.contains("đăng ký thành công")
                        || allText.contains("gửi tiền ngay lập tức")
                        || allText.contains("bắt đầu trò chơi")
                        || allText.contains("rút tiền");
                if (hasCongrats) {
                    dismissPopupsInTree(root);
                    broadcastStatusToApp("SUBMIT_NOW", "SUCCESS",
                            "Máy chủ đã xác nhận Đăng ký thành công TK: " + activeProfile.optString("username", "") + "!");
                    if (autoRunMode) {
                        currentAutoStage = 2;
                        mainHandler.postDelayed(this::continueAutoRunStageOnWindowChange, 950L);
                    }
                } else {
                    broadcastStatusToApp("SUBMIT_NOW", "PENDING",
                            "Đang chờ phản hồi xác nhận Đăng ký từ máy chủ...");
                }
            } finally {
                root.recycle();
            }
        }, 1500L);
    }

    private void scheduleBankOutcomeVerification(final String submittedStk) {
        mainHandler.postDelayed(() -> {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root == null) return;
            try {
                if (checkAndHandleServerAlert(root, "GO_BANK_PAGE")) return;
                String allText = collectVisibleScreenText(root);
                String last4 = submittedStk.length() >= 4 ? submittedStk.substring(submittedStk.length() - 4) : "";
                boolean confirmed = allText.contains("thêm ngân hàng thành công")
                        || allText.contains("liên kết ngân hàng thành công")
                        || allText.contains("thêm thẻ thành công")
                        || allText.contains("liên kết thành công")
                        || (!last4.isEmpty() && (allText.contains("***" + last4) || allText.contains("****" + last4)));
                if (confirmed) {
                    autoRunMode = false;
                    currentAutoStage = 0;
                    broadcastStatusToApp("GO_BANK_PAGE", "SUCCESS",
                            "Máy chủ đã xác nhận liên kết Ngân hàng thành công (***" + last4 + ")!");
                } else {
                    broadcastStatusToApp("GO_BANK_PAGE", "PENDING",
                            "Đã gửi biểu mẫu Ngân hàng — Đang chờ máy chủ xác nhận (PENDING)...");
                }
            } finally {
                root.recycle();
            }
        }, 1700L);
    }

    private void continueAutoRunStageOnWindowChange() {
        if (!autoRunMode) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        try {
            if (checkAndHandleServerAlert(root, "RUN_AUTO")) return;
            if (currentAutoStage == 2) {
                String wd = activeProfile != null ? activeProfile.optString("wd", "123123") : "123123";
                boolean filledPin = fillNodeByKeywords(root,
                        new String[]{"cài đặt mật khẩu rút tiền", "mật khẩu rút tiền", "xác nhận mật khẩu rút tiền"},
                        null, wd);
                if (filledPin) {
                    AccessibilityNodeInfo confirmPinBtn = findClickableNodeByKeywords(root,
                            new String[]{"xác nhận", "gửi đi"});
                    if (confirmPinBtn != null) clickNodeOrTapBounds(confirmPinBtn);
                }
                currentAutoStage = 3;
                mainHandler.postDelayed(this::handleGoBankPageCommand, 900L);
            }
        } finally {
            root.recycle();
        }
    }

    private int fillRegistrationFieldsOnScreen(AccessibilityNodeInfo root) {
        if (activeProfile == null) return 0;
        String username = activeProfile.optString("username", "");
        String pw       = activeProfile.optString("pw", "");
        String wd       = activeProfile.optString("wd", "123123");
        String fullName = activeProfile.optString("name", "");
        String phoneRaw = activeProfile.optString("phone", "");

        int filledCount = 0;

        if (!username.isEmpty()) {
            if (fillNodeByKeywords(root,
                    new String[]{"tên tài khoản", "tên đăng nhập", "từ 2-15", "username", "account", "tài khoản"},
                    new String[]{"mật khẩu", "họ và tên", "ngân hàng", "số tài khoản"}, username)) {
                filledCount++;
            }
        }
        if (!pw.isEmpty()) {
            if (fillNodeByKeywords(root,
                    new String[]{"mật khẩu thành viên", "hơn 6 ký tự", "userpass", "password", "mật khẩu"},
                    new String[]{"xác nhận", "nhập lại", "rút tiền", "giao dịch"}, pw)) {
                filledCount++;
            }
            if (fillNodeByKeywords(root,
                    new String[]{"xác nhận mật khẩu", "xác nhận lại mật khẩu", "nhập lại mật khẩu", "confirm", "repassword"},
                    new String[]{"rút tiền"}, pw)) {
                filledCount++;
            }
        }
        if (!wd.isEmpty()) {
            if (fillNodeByKeywords(root,
                    new String[]{"mật khẩu rút tiền", "mk rút tiền", "withdrawpassword", "moneypassword", "mật khẩu giao dịch"},
                    null, wd)) {
                filledCount++;
            }
        }
        if (!fullName.isEmpty()) {
            if (fillNodeByKeywords(root,
                    new String[]{"họ và tên", "họ tên", "tên thật", "chữ in hoa", "realname", "fullname"},
                    new String[]{"tài khoản", "đăng nhập", "mật khẩu", "xác minh"}, fullName)) {
                filledCount++;
            }
        }
        if (!phoneRaw.isEmpty()) {
            AccessibilityNodeInfo phoneNode = findEditableByKeywords(root,
                    new String[]{"số điện thoại", "điện thoại", "số di động", "sđt", "phone", "mobile"},
                    new String[]{"mật khẩu", "rút tiền", "xác minh", "họ và tên"});
            if (phoneNode != null) {
                String formattedPhone = formatPhoneSmartForNode(phoneRaw, phoneNode);
                if (setNodeTextValue(phoneNode, formattedPhone)) {
                    filledCount++;
                }
            }
        }
        tickAgreementCheckboxes(root);
        return filledCount;
    }

    private int fillBankFieldsOnScreen(AccessibilityNodeInfo root, boolean clickSubmitAfterFill) {
        if (activeProfile == null) return 0;
        String bank   = activeProfile.optString("bank", "TECHCOMBANK");
        String branch = activeProfile.optString("branch", "Ninh bình");
        String stk    = activeProfile.optString("stk", "");
        int filled = 0;

        AccessibilityNodeInfo bankSelect = findClickableNodeByKeywords(root,
                new String[]{"vui lòng chọn ngân hàng", "chọn ngân hàng phát hành", "chọn ngân hàng"});
        if (bankSelect != null) {
            clickNodeOrTapBounds(bankSelect);
            AccessibilityNodeInfo bankOption = findClickableNodeByKeywords(root, new String[]{bank.toLowerCase()});
            if (bankOption != null && clickNodeOrTapBounds(bankOption)) {
                filled++;
            }
        }

        if (!branch.isEmpty()) {
            if (fillNodeByKeywords(root,
                    new String[]{"chi nhánh", "thành phố", "hồ chí minh", "branch"},
                    new String[]{"số tài khoản", "9704"}, branch)) {
                filled++;
            }
        }
        if (!stk.isEmpty()) {
            if (fillNodeByKeywords(root,
                    new String[]{"số tài khoản", "9704", "994", "tài khoản ngân hàng"},
                    new String[]{"chi nhánh", "tên đăng nhập"}, stk)) {
                filled++;
            }
        }

        if (clickSubmitAfterFill && filled > 0 && !stk.isEmpty()) {
            AccessibilityNodeInfo submitBankBtn = findClickableNodeByKeywords(root,
                    new String[]{"gửi đi", "xác nhận", "thêm mới", "thêm"});
            if (submitBankBtn != null) {
                clickNodeOrTapBounds(submitBankBtn);
            }
        }
        return filled;
    }

    private boolean isBankFormScreen(AccessibilityNodeInfo root) {
        AccessibilityNodeInfo stkNode = findEditableByKeywords(root,
                new String[]{"số tài khoản", "9704", "994", "chi nhánh", "thành phố hồ chí minh"},
                new String[]{"tên đăng nhập", "mật khẩu thành viên"});
        if (stkNode != null) return true;
        String screenTxt = collectVisibleScreenText(root);
        return screenTxt.contains("vui lòng chọn ngân hàng") || screenTxt.contains("chọn ngân hàng phát hành");
    }

    private boolean checkAndHandleServerAlert(AccessibilityNodeInfo root, String cmd) {
        String alertStatus = scanServerAlerts(root);
        if ("RATE_LIMIT_429".equals(alertStatus)) {
            rateLimitCooldownUntilMs = System.currentTimeMillis() + 20_000L;
            pausedForUserVerification = true;
            autoRunMode = false;
            broadcastStatusToApp(cmd, "FAILED", "Máy chủ báo thao tác nhanh (429) — Tự động khóa Submit 20 giây!");
            return true;
        }
        if ("DUPLICATE_DETECTED".equals(alertStatus)) {
            pausedForUserVerification = true;
            autoRunMode = false;
            broadcastStatusToApp(cmd, "FAILED", "Website báo trùng Tài khoản hoặc STK ngân hàng!");
            return true;
        }
        if ("PAUSED_CAPTCHA_OTP".equals(alertStatus)) {
            pausedForUserVerification = true;
            broadcastStatusToApp(cmd, "PENDING", "Đang chờ bạn xác minh CAPTCHA / OTP trên màn hình.");
            return true;
        }
        return false;
    }

    private String scanServerAlerts(AccessibilityNodeInfo root) {
        Deque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            AccessibilityNodeInfo curr = queue.poll();
            String nodeText = getNodeCombinedLabel(curr);
            if (!nodeText.isEmpty() && nodeText.length() <= 180) {
                if (nodeText.contains("kết nối trực tuyến là bất thường")
                        || nodeText.contains("thao tác quá nhanh")
                        || nodeText.contains("quá nhiều yêu cầu")
                        || nodeText.matches(".*(^|[^0-9])429([^0-9]|$).*")) {
                    return "RATE_LIMIT_429";
                }
                if (nodeText.contains("tên tài khoản này đã tồn tại")
                        || nodeText.contains("tài khoản đã tồn tại")
                        || nodeText.contains("tên đăng nhập đã tồn tại")
                        || nodeText.contains("tài khoản ngân hàng đã tồn tại")
                        || nodeText.contains("số tài khoản đã tồn tại")) {
                    return "DUPLICATE_DETECTED";
                }
                if (nodeText.contains("trượt để hoàn thành")
                        || nodeText.contains("chọn theo thứ tự")
                        || nodeText.contains("nhập mã sms")
                        || nodeText.contains("mã xác minh điện thoại")) {
                    return "PAUSED_CAPTCHA_OTP";
                }
            }
            for (int i = 0; i < curr.getChildCount(); i++) {
                AccessibilityNodeInfo child = curr.getChild(i);
                if (child != null) queue.add(child);
            }
        }
        return null;
    }

    private String collectVisibleScreenText(AccessibilityNodeInfo root) {
        StringBuilder sb = new StringBuilder();
        Deque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            AccessibilityNodeInfo curr = queue.poll();
            if (curr.isVisibleToUser()) {
                if (curr.getText() != null) sb.append(curr.getText()).append(" ");
                if (curr.getContentDescription() != null) sb.append(curr.getContentDescription()).append(" ");
            }
            for (int i = 0; i < curr.getChildCount(); i++) {
                AccessibilityNodeInfo child = curr.getChild(i);
                if (child != null) queue.add(child);
            }
        }
        return sb.toString().toLowerCase();
    }

    /**
     * Giữ số 0 đầu SĐT mặc định; chỉ bỏ số 0 khi chính ô input có tiền tố +84 hoặc yêu cầu không nhập số 0 (Fix P1-02).
     */
    private String formatPhoneSmartForNode(String phoneRaw, AccessibilityNodeInfo phoneNode) {
        String clean = phoneRaw == null ? "" : phoneRaw.replaceAll("\\D+", "");
        if (clean.isEmpty()) return "";
        if (clean.startsWith("84") && clean.length() >= 11) {
            clean = "0" + clean.substring(2);
        }
        String label = getNodeCombinedLabel(phoneNode);
        AccessibilityNodeInfo parent = phoneNode.getParent();
        if (parent != null) {
            label = label + " " + getNodeCombinedLabel(parent);
        }
        if (label.contains("+84") || label.contains("84 |") || label.contains("không nhập số 0") || label.contains("bỏ số 0")) {
            return clean.replaceFirst("^0+", "");
        }
        return clean.startsWith("0") ? clean : ("0" + clean);
    }

    /**
     * Tìm ô Mã xác minh (4–6 ký tự cuối form):
     * Ưu tiên từ khóa mã xác minh / captcha; nếu không có nhãn thì lấy ô editable cuối cùng của form (>= 4 ô).
     */
    private AccessibilityNodeInfo findVerificationCodeNode(AccessibilityNodeInfo root) {
        AccessibilityNodeInfo byKeyword = findEditableByKeywords(root,
                new String[]{"mã xác minh", "xác nhận mã", "captcha", "verification", "checkcode", "mã bảo vệ", "mã xác nhận", "nhập mã"},
                new String[]{"mật khẩu", "rút tiền", "điện thoại", "họ và tên", "tài khoản"});
        if (byKeyword != null) return byKeyword;

        List<AccessibilityNodeInfo> allEditables = new ArrayList<>();
        collectEditableNodes(root, allEditables);
        if (allEditables.size() >= 4) {
            AccessibilityNodeInfo last = allEditables.get(allEditables.size() - 1);
            if (!last.isPassword()) {
                String lbl = getNodeCombinedLabel(last);
                if (!lbl.contains("tài khoản") && !lbl.contains("mật khẩu")
                        && !lbl.contains("họ tên") && !lbl.contains("điện thoại")) {
                    return last;
                }
            }
        }
        return null;
    }

    private void collectEditableNodes(AccessibilityNodeInfo node, List<AccessibilityNodeInfo> out) {
        if (node == null) return;
        if (node.isEditable() && node.isVisibleToUser()) {
            out.add(node);
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) collectEditableNodes(child, out);
        }
    }

    private boolean fillSingleFieldByType(AccessibilityNodeInfo root, String field, String val) {
        if (val == null || val.isEmpty()) return false;
        switch (field) {
            case "username":
                return fillNodeByKeywords(root, new String[]{"tên tài khoản", "tên đăng nhập", "username", "account", "tài khoản"},
                        new String[]{"mật khẩu", "họ và tên", "số tài khoản"}, val);
            case "pw":
                boolean ok1 = fillNodeByKeywords(root, new String[]{"mật khẩu thành viên", "mật khẩu", "password"},
                        new String[]{"xác nhận", "rút tiền"}, val);
                fillNodeByKeywords(root, new String[]{"xác nhận mật khẩu", "nhập lại mật khẩu", "confirm"},
                        new String[]{"rút tiền"}, val);
                return ok1;
            case "wd":
                return fillNodeByKeywords(root, new String[]{"mật khẩu rút tiền", "mk rút tiền", "withdraw", "giao dịch"},
                        null, val);
            case "name":
                return fillNodeByKeywords(root, new String[]{"họ và tên", "họ tên", "tên thật", "fullname", "realname"},
                        new String[]{"tài khoản", "mật khẩu"}, val);
            case "phone":
                AccessibilityNodeInfo pNode = findEditableByKeywords(root,
                        new String[]{"số điện thoại", "điện thoại", "di động", "phone", "mobile"},
                        new String[]{"mật khẩu", "xác minh"});
                return pNode != null && setNodeTextValue(pNode, formatPhoneSmartForNode(val, pNode));
            case "stk":
                return fillNodeByKeywords(root, new String[]{"số tài khoản", "9704", "994", "tài khoản ngân hàng"},
                        new String[]{"chi nhánh"}, val);
            default:
                return false;
        }
    }

    private void tickAgreementCheckboxes(AccessibilityNodeInfo root) {
        Deque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            AccessibilityNodeInfo curr = queue.poll();
            if (curr.isCheckable() && !curr.isChecked()) {
                String lbl = getNodeCombinedLabel(curr);
                AccessibilityNodeInfo p = curr.getParent();
                if (p != null) lbl += " " + getNodeCombinedLabel(p);
                if (lbl.contains("đồng ý") || lbl.contains("điều khoản") || lbl.contains("18 tuổi") || lbl.contains("thỏa thuận")) {
                    clickNodeOrTapBounds(curr);
                }
            }
            for (int i = 0; i < curr.getChildCount(); i++) {
                AccessibilityNodeInfo child = curr.getChild(i);
                if (child != null) queue.add(child);
            }
        }
    }

    private AccessibilityNodeInfo findRegisterSubmitButton(AccessibilityNodeInfo root) {
        Deque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        queue.add(root);
        AccessibilityNodeInfo candidate = null;
        while (!queue.isEmpty()) {
            AccessibilityNodeInfo curr = queue.poll();
            String lbl = getNodeCombinedLabel(curr);
            if (curr.isVisibleToUser() && (curr.isClickable() || (curr.getClassName() != null && curr.getClassName().toString().contains("Button")))) {
                if (lbl.contains("đăng ký người dùng mới") || lbl.contains("đăng ký ngay")
                        || lbl.contains("hoàn tất đăng ký") || lbl.equals("đăng ký")
                        || lbl.equals("đăng kí") || lbl.equals("register")) {
                    candidate = curr;
                }
            }
            for (int i = 0; i < curr.getChildCount(); i++) {
                AccessibilityNodeInfo child = curr.getChild(i);
                if (child != null) queue.add(child);
            }
        }
        return candidate;
    }

    private AccessibilityNodeInfo findClickableNodeByKeywords(AccessibilityNodeInfo root, String[] keywords) {
        Deque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            AccessibilityNodeInfo curr = queue.poll();
            if (curr.isVisibleToUser()) {
                String lbl = getNodeCombinedLabel(curr);
                for (String kw : keywords) {
                    if (lbl.contains(kw.toLowerCase())) {
                        if (curr.isClickable()) return curr;
                        AccessibilityNodeInfo p = curr.getParent();
                        if (p != null && p.isClickable()) return p;
                        return curr;
                    }
                }
            }
            for (int i = 0; i < curr.getChildCount(); i++) {
                AccessibilityNodeInfo child = curr.getChild(i);
                if (child != null) queue.add(child);
            }
        }
        return null;
    }

    private int dismissPopupsInTree(AccessibilityNodeInfo root) {
        int count = 0;
        Deque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            AccessibilityNodeInfo curr = queue.poll();
            String lbl = getNodeCombinedLabel(curr);
            if (curr.isVisibleToUser() && curr.isClickable()) {
                if (lbl.equals("đóng") || lbl.equals("close") || lbl.equals("×") || lbl.equals("✕") || lbl.equals("ẩn vĩnh viễn")) {
                    if (clickNodeOrTapBounds(curr)) count++;
                }
            }
            for (int i = 0; i < curr.getChildCount(); i++) {
                AccessibilityNodeInfo child = curr.getChild(i);
                if (child != null) queue.add(child);
            }
        }
        return count;
    }

    public boolean fillNodeByKeywords(AccessibilityNodeInfo root, String[] includeKeys, String[] excludeKeys, String value) {
        if (root == null || value == null || value.isEmpty()) return false;
        AccessibilityNodeInfo target = findEditableByKeywords(root, includeKeys, excludeKeys);
        if (target == null) return false;
        return setNodeTextValue(target, value);
    }

    private boolean setNodeTextValue(AccessibilityNodeInfo target, String value) {
        if (target == null || value == null) return false;
        CharSequence existing = target.getText();
        if (existing != null && existing.toString().equals(value)) {
            return true;
        }
        Bundle args = new Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value);
        target.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
    }

    private AccessibilityNodeInfo findEditableByKeywords(AccessibilityNodeInfo root, String[] includeKeys, String[] excludeKeys) {
        Deque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            AccessibilityNodeInfo curr = queue.poll();
            if (curr.isEditable() && curr.isVisibleToUser()) {
                String label = getNodeCombinedLabel(curr);
                AccessibilityNodeInfo parent = curr.getParent();
                if (parent != null) {
                    label = label + " " + getNodeCombinedLabel(parent);
                }
                boolean excluded = false;
                if (excludeKeys != null) {
                    for (String ex : excludeKeys) {
                        if (label.contains(ex.toLowerCase())) {
                            excluded = true;
                            break;
                        }
                    }
                }
                if (!excluded && includeKeys != null) {
                    for (String inc : includeKeys) {
                        if (label.contains(inc.toLowerCase())) {
                            return curr;
                        }
                    }
                }
            }
            for (int i = 0; i < curr.getChildCount(); i++) {
                AccessibilityNodeInfo child = curr.getChild(i);
                if (child != null) queue.add(child);
            }
        }
        return null;
    }

    private String getNodeCombinedLabel(AccessibilityNodeInfo node) {
        if (node == null) return "";
        StringBuilder sb = new StringBuilder();
        if (node.getText() != null) sb.append(node.getText()).append(" ");
        if (node.getContentDescription() != null) sb.append(node.getContentDescription()).append(" ");
        if (Build.VERSION.SDK_INT >= 26 && node.getHintText() != null) sb.append(node.getHintText()).append(" ");
        if (node.getViewIdResourceName() != null) sb.append(node.getViewIdResourceName()).append(" ");
        return sb.toString().trim().toLowerCase();
    }

    public boolean clickNodeOrTapBounds(AccessibilityNodeInfo node) {
        if (node == null) return false;
        if (node.isClickable() && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            return true;
        }
        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);
        if (bounds.width() > 0 && bounds.height() > 0 && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Path clickPath = new Path();
            clickPath.moveTo(bounds.centerX(), bounds.centerY());
            GestureDescription.StrokeDescription stroke =
                    new GestureDescription.StrokeDescription(clickPath, 0, 80);
            GestureDescription.Builder builder = new GestureDescription.Builder();
            builder.addStroke(stroke);
            return dispatchGesture(builder.build(), null, null);
        }
        return false;
    }

    /**
     * Phát phản hồi kết quả (SUCCESS / FAILED / PENDING) đồng thời qua 3 đường (Fix #3):
     * 1. Broadcast Intent `com.cholibi.app.A11Y_STATUS` (kèm `payload_json`).
     * 2. Lưu vào SharedPreferences `A11Y_LAST_STATUS_JSON` để DroidScript đọc qua `PollA11yStatusFileTick()`.
     * 3. Gọi trực tiếp `MainActivity.deliverA11yStatusToWebView(jsonStr)` khi chạy trong APK độc lập.
     */
    /**
     * Kéo thật bằng AccessibilityService.dispatchGesture — Tạo MotionEvent cấp hệ thống
     * (isTrusted = true trong WebView / Orbita / Chrome).
     */
    private void performTrustedDrag(float vpX, float vpY, float distX, float distY, int durationMs) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            broadcastStatusToApp("SLIDER_DRAG_FAILED", "FAILED", "Android < 7.0 không hỗ trợ dispatchGesture");
            return;
        }
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        float density = dm.density;

        // Tọa độ từ getBoundingClientRect() là CSS px -> đổi sang physical screen px
        // Cộng thêm offset thanh status bar (~24dp) + header app (~48dp)
        float statusBarPlusHeaderDp = 72f;
        float sx = vpX * density;
        float sy = (vpY + statusBarPlusHeaderDp) * density;
        float ex = (vpX + distX) * density;
        float ey = (vpY + distY + statusBarPlusHeaderDp) * density;

        // Giữ tọa độ nằm trong giới hạn màn hình vật lý an toàn
        sx = Math.max(10f, Math.min(dm.widthPixels - 10f, sx));
        sy = Math.max(10f, Math.min(dm.heightPixels - 10f, sy));
        ex = Math.max(10f, Math.min(dm.widthPixels - 10f, ex));
        ey = Math.max(10f, Math.min(dm.heightPixels - 10f, ey));

        // Tạo đường cong Bezier bậc 3 (mô phỏng đường cong S + hơi võng tay)
        Path path = new Path();
        path.moveTo(sx, sy);

        float ctrl1X = sx + (ex - sx) * 0.25f;
        float ctrl1Y = sy - 4f * density; // hơi nhích lên đầu
        float ctrl2X = sx + (ex - sx) * 0.75f;
        float ctrl2Y = ey + 3f * density; // hơi võng xuống cuối
        path.cubicTo(ctrl1X, ctrl1Y, ctrl2X, ctrl2Y, ex, ey);

        int dur = Math.max(400, Math.min(2500, durationMs));
        GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(path, 0, dur);
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(stroke)
                .build();

        boolean dispatched = dispatchGesture(gesture, new GestureResultCallback() {
            @Override
            public void onCompleted(GestureDescription g) {
                broadcastStatusToApp("SLIDER_DRAG_DONE", "OK");
            }
            @Override
            public void onCancelled(GestureDescription g) {
                broadcastStatusToApp("SLIDER_DRAG_FAILED", "Cancelled by system");
            }
        }, null);

        if (!dispatched) {
            broadcastStatusToApp("SLIDER_DRAG_FAILED", "dispatchGesture returned false");
        }
    }

    private void broadcastStatusToApp(String cmdOrStatus, String message) {
        String normalizedStatus = (cmdOrStatus != null && (cmdOrStatus.contains("DONE") || cmdOrStatus.contains("SUCCESS")))
                ? "SUCCESS" : "FAILED";
        broadcastStatusToApp(cmdOrStatus, normalizedStatus, message);
    }

    private void broadcastStatusToApp(String cmd, String status, String message) {
        try {
            JSONObject obj = new JSONObject();
            obj.put("cmd", cmd != null ? cmd : "A11Y");
            obj.put("status", status != null ? status : "PENDING");
            obj.put("message", message != null ? message : "");
            obj.put("ts", System.currentTimeMillis());
            String jsonStr = obj.toString();

            if (securityAndProxyManager != null) {
                securityAndProxyManager.saveLastA11yStatusJson(jsonStr);
            }

            MainActivity.deliverA11yStatusToWebView(jsonStr);

            Intent intent = new Intent(ACTION_A11Y_STATUS);
            intent.putExtra("cmd", cmd != null ? cmd : "A11Y");
            intent.putExtra("status", status);
            intent.putExtra("message", message);
            intent.putExtra("payload_json", jsonStr);
            sendBroadcast(intent);
        } catch (Exception ignored) {}
    }
}