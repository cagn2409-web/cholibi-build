package com.cholibi.app;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.ref.WeakReference;
import java.nio.charset.StandardCharsets;

/**
 * MainActivity — Màn hình chính của APK CHOLIBI v31.2 Master Fixed.
 *
 * Kết nối trực tiếp 2 chiều giữa:
 * - Mã JavaScript `assets/CHOLIBI_v31_MASTER_FIXED.js`
 * - Dịch vụ Android Accessibility `CholibiAccessibilityService.java`
 * - Quản lý bảo mật KeyStore & Proxy `CholibiSecurityAndProxyManager.java`
 */
public final class MainActivity extends Activity {
    private static WeakReference<MainActivity> activeInstanceRef = new WeakReference<>(null);

    private WebView webView;
    private EditText urlInput;
    private TextView statusTxt;
    private Spinner siteSpinner;
    private String cachedInjectedPayloadFunc = null;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private CholibiSecurityAndProxyManager securityManager;

    private static final String[] SITES = new String[]{
            "NOHU88", "GO99", "TT88", "789P", "MMOO",
            "SC88", "CM88", "C168", "J88", "U888", "VAN88"
    };

    private static final String[] DEFAULT_URLS = new String[]{
            "https://m.nohu90.com/Account/Register?f=6344995",
            "https://m.1go99.vip/?f=3528698&app=1",
            "https://m.1tt88.vip/?f=3535864&app=1",
            "https://m.789p1.vip/?f=784461&app=1",
            "https://m.mmoo.team/?f=394579&app=1",
            "https://sc88yy.com/home/register",
            "https://cm88az.vip/home/register",
            "https://c1686.net/home/register",
            "https://m.j88qqgh.buzz/Account/Register?r=EOKXXP6&app=1",
            "https://m.u888288.xyz/Register?r=0R0RVZ4&app=1",
            "https://m.66van88.com/Register?a=44403"
    };

    private final BroadcastReceiver a11yStatusReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent == null) return;
            String json = intent.getStringExtra("payload_json");
            if (json != null && !json.isEmpty()) {
                forwardA11yStatusJsonToWeb(json);
            }
        }
    };

    public static void deliverA11yStatusToWebView(final String statusJson) {
        final MainActivity act = activeInstanceRef.get();
        if (act != null && statusJson != null) {
            act.runOnUiThread(() -> act.forwardA11yStatusJsonToWeb(statusJson));
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activeInstanceRef = new WeakReference<>(this);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        securityManager = new CholibiSecurityAndProxyManager(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF0D1113);

        // Thanh điều hướng phía trên
        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setBackgroundColor(0xFF141B1F);
        topBar.setPadding(10, 6, 10, 6);

        siteSpinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_dropdown_item, SITES);
        siteSpinner.setAdapter(adapter);
        topBar.addView(siteSpinner, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 2.2f));

        urlInput = new EditText(this);
        urlInput.setSingleLine(true);
        urlInput.setTextSize(11f);
        urlInput.setTextColor(0xFFBDC3C7);
        urlInput.setBackgroundColor(0xFF0B0F12);
        urlInput.setText(DEFAULT_URLS[0]);
        topBar.addView(urlInput, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 3.8f));

        Button btnGo = new Button(this);
        btnGo.setText("Đi");
        btnGo.setTextSize(10f);
        btnGo.setOnClickListener(v -> {
            String u = urlInput.getText().toString().trim();
            if (!u.isEmpty() && webView != null) {
                if (!u.startsWith("http://") && !u.startsWith("https://")) {
                    u = "https://" + u;
                }
                webView.loadUrl(u);
            }
        });
        topBar.addView(btnGo, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.1f));

        Button btnA11y = new Button(this);
        btnA11y.setText("A11y");
        btnA11y.setTextSize(9.5f);
        btnA11y.setOnClickListener(v -> openAccessibilitySettings());
        topBar.addView(btnA11y, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.3f));

        Button btnOrbita = new Button(this);
        btnOrbita.setText("Orbita");
        btnOrbita.setTextSize(9.5f);
        btnOrbita.setOnClickListener(v -> launchExternalPackage("org.gologin.orbita", "Orbita"));
        topBar.addView(btnOrbita, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.5f));

        root.addView(topBar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        // Thanh trạng thái
        statusTxt = new TextView(this);
        statusTxt.setText("🟢 CHOLIBI v31.2 Master Fixed — Sẵn sàng điều khiển 11 cổng game & Accessibility");
        statusTxt.setTextSize(10.5f);
        statusTxt.setTextColor(0xFF2ECC71);
        statusTxt.setBackgroundColor(0xFF090C0E);
        statusTxt.setPadding(16, 4, 16, 4);
        root.addView(statusTxt, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        // WebView chính
        webView = new WebView(this);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        ws.setBuiltInZoomControls(true);
        ws.setDisplayZoomControls(false);
        ws.setUserAgentString("Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36");

        webView.addJavascriptInterface(new CholibiNativeJsBridge(), "CholibiNativeBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP && request != null && request.getUrl() != null) {
                    String u = request.getUrl().toString();
                    if (u.startsWith("cholibi-bridge://")) {
                        return true;
                    }
                }
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (url != null && url.startsWith("http")) {
                    urlInput.setText(url);
                    injectCholibiMasterScript();
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                if (consoleMessage != null && consoleMessage.message() != null) {
                    String msg = consoleMessage.message();
                    if (msg.startsWith("CHOLIBI_NATIVE_DRAG:")) {
                        try {
                            String b64 = msg.substring("CHOLIBI_NATIVE_DRAG:".length()).trim();
                            String jsonStr = new String(android.util.Base64.decode(b64, android.util.Base64.DEFAULT), java.nio.charset.StandardCharsets.UTF_8);
                            Intent dragIntent = new Intent(CholibiAccessibilityService.ACTION_SLIDER_DRAG);
                            dragIntent.setPackage(getPackageName());
                            dragIntent.putExtra("payload_json", jsonStr);
                            sendBroadcast(dragIntent);
                        } catch (Exception ignored) {}
                        return true;
                    }
                    if ("CHOLIBI_NEED_INJECT".equals(msg)) {
                        injectCholibiMasterScript();
                    }
                }
                return super.onConsoleMessage(consoleMessage);
            }
        });

        root.addView(webView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        siteSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            private boolean firstInit = true;
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (firstInit) {
                    firstInit = false;
                    return;
                }
                if (position >= 0 && position < DEFAULT_URLS.length) {
                    String target = DEFAULT_URLS[position];
                    urlInput.setText(target);
                    webView.loadUrl(target);
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        IntentFilter filter = new IntentFilter(CholibiAccessibilityService.ACTION_A11Y_STATUS);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(a11yStatusReceiver, filter, Context.RECEIVER_EXPORTED);
        } else {
            registerReceiver(a11yStatusReceiver, filter);
        }

        webView.loadUrl(DEFAULT_URLS[0]);
    }

    private void forwardA11yStatusJsonToWeb(String jsonStr) {
        if (statusTxt != null) {
            statusTxt.setText("🤖 A11y: " + jsonStr);
        }
        if (webView != null && jsonStr != null) {
            String b64 = Base64.encodeToString(jsonStr.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
            String js = "if(window.__cholibiOnA11yStatus){window.__cholibiOnA11yStatus('" + b64 + "');}"
                    + "if(window.OnNativeA11yStatusBridge){window.OnNativeA11yStatusBridge(" + JSONObjectQuote(jsonStr) + ");}";
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                webView.evaluateJavascript(js, null);
            } else {
                webView.loadUrl("javascript:" + js);
            }
        }
    }

    private String JSONObjectQuote(String raw) {
        return org.json.JSONObject.quote(raw != null ? raw : "{}");
    }

    private void injectCholibiMasterScript() {
        if (webView == null) return;
        try {
            if (cachedInjectedPayloadFunc == null) {
                cachedInjectedPayloadFunc = loadAssetText("CHOLIBI_v31_MASTER_FIXED.js");
            }
            if (cachedInjectedPayloadFunc != null && !cachedInjectedPayloadFunc.isEmpty()) {
                SharedPreferences sp = getSharedPreferences("CHOLIBI_APP_STORAGE_V6", Context.MODE_PRIVATE);
                String savedVault = sp.getString("CHOLIBI_LOCKED_PROFILE_VAULT_V6", "{}");
                String savedMaster = sp.getString("CHOLIBI_MASTER_FORM_STATE_V6", "{}");
                String invokeJs = cachedInjectedPayloadFunc + "\n"
                        + "if(typeof CholibiInjectedPayload==='function'){"
                        + "CholibiInjectedPayload(SITE_CONFIGS," + savedMaster + "," + savedVault + ",true,'apk_bridge_tok');"
                        + "}";
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    webView.evaluateJavascript(invokeJs, null);
                } else {
                    webView.loadUrl("javascript:" + invokeJs);
                }
            }
        } catch (Exception ignored) {}
    }

    private String loadAssetText(String fileName) {
        StringBuilder sb = new StringBuilder();
        try (InputStream is = getAssets().open(fileName);
             BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line).append('\n');
            }
        } catch (Exception ignored) {}
        return sb.toString();
    }

    private void openAccessibilitySettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            Toast.makeText(this, "⚙️ Hãy bật dịch vụ CHOLIBI Orbita Helper trong Hỗ trợ tiếp cận!", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Không mở được Cài đặt Trợ năng: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void launchExternalPackage(String pkg, String name) {
        try {
            Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
            if (launch != null) {
                startActivity(launch);
            } else {
                Intent store = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + pkg));
                startActivity(store);
            }
        } catch (Exception e) {
            Toast.makeText(this, "Không mở được " + name, Toast.LENGTH_SHORT).show();
        }
    }

    public final class CholibiNativeJsBridge {
        @JavascriptInterface
        public void sendAction(String actionName, String payloadJson) {
            if (actionName == null || actionName.isEmpty()) return;
            Intent intent = new Intent(actionName);
            intent.setPackage(getPackageName());
            intent.putExtra("payload_json", payloadJson != null ? payloadJson : "{}");
            sendBroadcast(intent);
        }

        @JavascriptInterface
        public void copyToClipboard(String text) {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null && text != null) {
                cm.setPrimaryClip(ClipData.newPlainText("cholibi", text));
            }
        }
    }

    @Override
    protected void onDestroy() {
        try {
            unregisterReceiver(a11yStatusReceiver);
        } catch (Exception ignored) {}
        super.onDestroy();
    }
}
