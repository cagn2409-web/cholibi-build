package com.cholibi.fixture;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Test-only local HTML fixture supporting all 6 CHOLIBI site profiles
 * (SC88, CM88, C168, J88, U888, VAN88), DomStorage, CAPTCHA pause,
 * and duplicate account/bank simulation.
 * No Internet permission and no remote resource loading.
 */
public final class FixtureActivity extends Activity {
    private WebView web;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        String address = getIntent().getStringExtra("address");
        if (address == null) address = "https://sc88yy.com/home/register";
        final String reportedAddress = address;
        boolean captcha = getIntent().getBooleanExtra("captcha", false);
        boolean duplicateAccount = getIntent().getBooleanExtra("duplicateAccount", false);
        boolean duplicateBank = getIntent().getBooleanExtra("duplicateBank", false);
        boolean isVan88 = address.toLowerCase().contains("66van88") || address.toLowerCase().contains("van88");

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        TextView bar = new TextView(this);
        bar.setId(R.id.url_bar);
        bar.setText(address);
        bar.setTextSize(16);
        bar.setPadding(12, 12, 12, 12);
        bar.setFocusable(false);
        root.addView(bar);

        web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true); // Bật localStorage / sessionStorage cho Auto Resume
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);

        web.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void report(String json) {
                Intent report = new Intent("com.cholibi.fixture.REPORT");
                report.setPackage("com.cholibi.app");
                report.putExtra("address", reportedAddress);
                report.putExtra("data", json);
                sendBroadcast(report);
            }
        }, "Fixture");

        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        String html = "<!doctype html><html lang='vi'><meta charset='utf-8'>"
            + "<meta name='viewport' content='width=device-width,initial-scale=1'>"
            + "<style>body{font:18px sans-serif}input{font:18px sans-serif;display:block;width:90%;margin:8px 0;padding:6px}.err{color:#e74c3c;font-size:14px}</style>"
            + "<input id='username' aria-label='Tên đăng nhập' placeholder='Tên đăng nhập' autocomplete='off'>"
            + (duplicateAccount ? "<div id='dup-acc' class='err'>Tên tài khoản này đã tồn tại</div>" : "")
            + "<input id='password' aria-label='Mật khẩu' placeholder='Mật khẩu' type='password' autocomplete='off'>"
            + (isVan88 ? "<input id='confirm' aria-label='Xác nhận mật khẩu' placeholder='Xác nhận mật khẩu' type='password' autocomplete='off'>" : "")
            + "<input id='fullname' aria-label='Họ và tên' placeholder='Họ và tên'>"
            + "<input id='phone' aria-label='Số điện thoại' placeholder='Số điện thoại' type='tel'>"
            + (captcha ? "<input id='captcha' aria-label='CAPTCHA' placeholder='Nhập 4 số CAPTCHA'>" : "")
            + (duplicateBank ? "<div id='dup-bank' class='err'>Tài khoản ngân hàng đã tồn tại trên hệ thống</div>" : "")
            + "<button onclick='submissions++'>Đăng Ký</button>"
            + "<script>var submissions=0;setInterval(function(){var x={submissions:submissions};"
            + "['username','password','confirm','fullname','phone','captcha'].forEach(function(k){var n=document.getElementById(k);x[k]=n?n.value:'';});"
            + "Fixture.report(JSON.stringify(x));},250);</script></html>";

        web.loadDataWithBaseURL("https://fixture.invalid/", html, "text/html", "UTF-8", null);
    }

    @Override
    public void onDestroy() {
        if (web != null) {
            web.removeJavascriptInterface("Fixture");
            web.destroy();
        }
        super.onDestroy();
    }
}