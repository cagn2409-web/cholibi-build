# Dự án Android Studio hoàn chỉnh — CHOLIBI v31.2 Master Fixed

## Cấu trúc dự án
- `app/src/main/AndroidManifest.xml`: Khai báo `MainActivity`, `FixtureActivity` và dịch vụ `CholibiAccessibilityService`.
- `app/src/main/res/xml/accessibility_service_config.xml`: Cấu hình Accessibility hỗ trợ `typeViewTextChanged`, `canRetrieveWindowContent="true"`, `canPerformGestures="true"` cho Orbita, GoLogin, Chrome và WebView nội bộ.
- `app/src/main/java/com/cholibi/app/MainActivity.java`: Activity chính nhúng WebView, thanh chọn 11 cổng game, cầu nối 2 chiều `CholibiNativeBridge` và bộ nhận `A11Y_STATUS`.
- `app/src/main/java/com/cholibi/app/CholibiAccessibilityService.java`: Dịch vụ Trợ năng thực thi riêng từng lệnh (`RUN_AUTO`, `FILL_CURRENT_FORM`, `NEW_USER_AND_FILL`, `SUBMIT_NOW`, `GO_BANK_PAGE`, `CLEAN_POPUPS`, `FILL_SINGLE_FIELD`), tự bắt sự kiện gõ 4–6 ký tự vào ô Mã xác minh cuối form và báo cáo `SUCCESS` / `FAILED` / `PENDING`.
- `app/src/main/java/com/cholibi/app/CholibiSecurityAndProxyManager.java`: Mã hóa `pw`, `wd`, `proxy` bằng phần cứng AndroidKeyStore (AES-GCM 256-bit) và áp dụng `ProxyController` thực tế.
- `app/src/main/assets/CHOLIBI_v31_MASTER_FIXED.js`: Toàn bộ mã nguồn giao diện & điều khiển CHOLIBI v31.2.

## Hướng dẫn biên dịch ra file APK
1. Giải nén `CHOLIBI_v31_2_Android_Studio_Project.zip`.
2. Mở thư mục giải nén trong **Android Studio** -> chọn **Build > Build Bundle(s) / APK(s) > Build APK(s)** (hoặc chạy lệnh `./gradlew assembleDebug`).
3. Sau khi cài APK lên máy Android: vào **Cài đặt > Hỗ trợ tiếp cận (Accessibility) > CHOLIBI Orbita Helper v31.2** và bật dịch vụ.
